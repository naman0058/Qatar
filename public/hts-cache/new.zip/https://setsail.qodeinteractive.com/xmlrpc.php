<!DOCTYPE html>
<html lang="en-US">
<head>
<meta property="og:url" content="https://setsail.qodeinteractive.com/xmlrpc.php" />
<meta property="og:type" content="article" />
<meta property="og:title" content="SetSail" />
<meta property="og:description" content="Travel Agency Theme" />
<meta property="og:image" content="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/open_graph.jpg" />
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
<title>Page not found &#8211; SetSail</title>
<script type="application/javascript">var qodefToursAjaxURL = "https://setsail.qodeinteractive.com/wp-admin/admin-ajax.php"</script><meta name='robots' content='max-image-preview:large' />

<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//apis.google.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//static.zdassets.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="SetSail &raquo; Feed" href="https://setsail.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="SetSail &raquo; Comments Feed" href="https://setsail.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/setsail.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://setsail.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='titan-adminbar-styles-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/anti-spam/assets/css/admin-bar.css' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='rabbit_css-css' href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=5.7' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='setsail-membership-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-membership/assets/css/membership.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-membership-responsive-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-membership/assets/css/membership-responsive.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-modules-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/modules.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-tours-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/css/tours.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-modules-responsive-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/modules-responsive.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-tours-responsive-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/css/tours-responsive.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='nouislider-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/css/nouislider.min.css' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='swiper-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/swiper.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-grid-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-helper-parts-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-default-style-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-dripicons-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/dripicons/dripicons.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_elegant-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/elegant-icons/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_awesome-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-ion_icons-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/ion-icons/css/ionicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linea_icons-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/linea-icons/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linear_icons-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/linear-icons/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-simple_line_icons-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://setsail.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://setsail.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-woo-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/woocommerce.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-woo-responsive-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/woocommerce-responsive.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-style-dynamic-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/style_dynamic.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-style-dynamic-responsive-css' href='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/css/style_dynamic_responsive.css' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-select-google-fonts-css' href='https://fonts.googleapis.com/css?family=Poppins%3A300%2C400%2C500%2C600%2C700%2C800%7CCatamaran%3A300%2C400%2C500%2C600%2C700%2C800%7CSatisfy%3A300%2C400%2C500%2C600%2C700%2C800&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='setsail-core-dashboard-style-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/core-dashboard/assets/css/core-dashboard.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='qode-zendesk-chat-css' href='https://setsail.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css' type='text/css' media='all' />
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js' id='jquery-core-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js' id='tp-tools-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js' id='revmin-js'></script>
<script type='text/javascript' src='https://apis.google.com/js/platform.js' id='setsail-membership-google-plus-api-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/setsail.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js' id='gtm4wp-form-move-tracker-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://setsail.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://setsail.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://setsail.qodeinteractive.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.7" />
<meta name="generator" content="WooCommerce 5.1.0" />

<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M4XZBMN');//]]>
</script>

 <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<meta name="generator" content="Powered by Slider Revolution 6.4.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/cropped-favicon-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/cropped-favicon-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/cropped-favicon-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/cropped-favicon-1-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<style type="text/css" id="wp-custom-css">
			.qodef-woo-single-page .woocommerce-tabs #reviews .comment-respond .stars a.active:after, .qodef-woo-single-page .woocommerce-tabs #reviews .comment-respond .stars a:before{
	letter-spacing: 10px;
}

.qodef-woo-single-page .woocommerce-tabs #reviews .comment-respond .stars > span{
	font-size: 0;
}

.qodef-woo-single-page .woocommerce-tabs #reviews .comment-respond .stars a.active:after{
	bottom: 6px;
}

.qodef-parallax-row-holder {
    background-size: cover;
}

.qodef-row-grid-section-wrapper{
	background-size: cover;
}

.qodef-title-holder.qodef-bg-parallax {
    background-size: cover;
}		</style>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 theme-setsail setsail-core-1.2.1 qodef-social-login-1.0.2 qodef-tours-1.0.4 woocommerce-no-js qodef-qi--no-touch qi-addons-for-elementor-1.2.2 setsail-ver-1.6.1 qodef-grid-1300 qodef-page-content-is-boxed qodef-content-overlapping qodef-wide-dropdown-menu-content-in-grid qodef-sticky-header-on-scroll-down-up qodef-dropdown-animate-height qodef-header-standard qodef-menu-area-shadow-disable qodef-menu-area-in-grid-shadow-disable qodef-menu-area-border-disable qodef-menu-area-in-grid-border-disable qodef-logo-area-border-disable qodef-logo-area-in-grid-border-disable qodef-header-vertical-shadow-disable qodef-header-vertical-border-disable qodef-side-menu-slide-from-right qodef-woocommerce-columns-3 qodef-woo-small-space qodef-woo-pl-info-below-image qodef-woo-single-thumb-below-image qodef-woo-single-has-pretty-photo qodef-default-mobile-header qodef-sticky-up-mobile-header qodef-header-top-enabled qodef-fullscreen-search qodef-search-fade wpb-js-composer js-comp-ver-6.6.0 vc_responsive elementor-default elementor-kit-5345" itemscope itemtype="http://schema.org/WebPage">
<section class="qodef-side-menu">
<a class="qodef-close-side-menu qodef-close-side-menu-svg-path" href="#">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="18px" height="18px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
<line fill="none" x1="5.4" y1="15.6" x2="5.4" y2="15.6" />
<line stroke-width="1.5" stroke-miterlimit="10" x1="0.5" y1="0.6" x2="19.4" y2="19.4" />
<line stroke-width="1.5" stroke-miterlimit="10" x1="19.4" y1="0.6" x2="0.6" y2="19.4" />
</svg> </a>
<div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 13px"></div>
</div>
</div><div id="media_image-4" class="widget qodef-sidearea widget_media_image"><img width="204" height="65" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo-sidearea.png" class="image wp-image-4718  attachment-full size-full" alt="f" loading="lazy" style="max-width: 100%; height: auto;" /></div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 7px"></div>
</div>
</div><div id="media_image-7" class="widget qodef-sidearea widget_media_image"><img width="282" height="63" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/sidearea-img-2.png" class="image wp-image-294  attachment-full size-full" alt="s" loading="lazy" style="max-width: 100%; height: auto;" /></div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 40px"></div>
</div>
</div><div id="media_image-5" class="widget qodef-sidearea widget_media_image"><a href="https://setsail.qodeinteractive.com/contact-us/"><img width="385" height="237" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/sidearea-img.jpg" class="image wp-image-4654 qodef-image-with-shadow attachment-full size-full" alt="f" loading="lazy" style="max-width: 100%; height: auto;" srcset="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/sidearea-img.jpg 385w, https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/sidearea-img-300x185.jpg 300w" sizes="(max-width: 385px) 100vw, 385px" /></a></div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 15px"></div>
</div>
</div><div id="text-5" class="widget qodef-sidearea widget_text"> <div class="textwidget"><p style="text-align: center;">Lorem ipsum dolor sit amet, consectetuer adipis cing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis theme natoque</p>
</div>
</div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 25px"></div>
</div>
</div><div id="search-3" class="widget qodef-sidearea widget_search"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">Find Your Destination</h5></div><form role="search" method="get" class="qodef-searchform searchform" id="searchform-762" action="https://setsail.qodeinteractive.com/">
<label class="screen-reader-text">Search for:</label>
<div class="input-holder clearfix">
<input type="search" class="search-field" placeholder="Search..." value="" name="s" title="Search for:" />
<button type="submit" class="qodef-search-submit"><span aria-hidden="true" class="qodef-icon-font-elegant icon_search "></span></button>
</div>
</form></div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 30px"></div>
</div>
</div><div class="widget qodef-social-icons-group-widget qodef-circle-icons text-align-center"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">Follow Me</h5></div> <a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 16px;margin: 18px 7px -9px 0;" href="https://twitter.com/QodeInteractive" target="_blank">
<span class="qodef-social-icon-widget fab fa-twitter"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 16px;margin: 18px 7px -9px 0;" href="https://www.pinterest.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-pinterest-p"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 16px;margin: 18px 7px -9px 0;" href="https://www.facebook.com/QodeInteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-facebook-f"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 16px;margin: 18px 7px -9px 0;" href="https://www.instagram.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-instagram"></span> </a>
</div></section>
<div class="qodef-wrapper">
<div class="qodef-wrapper-inner">
<div class="qodef-top-bar">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<a class="qodef-icon-widget-holder" href="/cdn-cgi/l/email-protection#116274656270787d51607e75743f727e7c" target="_self" style="margin: 0 20px 0 0">
<span class="qodef-icon-element icon_mail_alt" style="font-size: 14px"></span> <span class="qodef-icon-text "><span class="__cf_email__" data-cfemail="4231273631232b2e02332d26276c212d2f">[email&#160;protected]</span></span> </a>
<a class="qodef-icon-widget-holder" href="tel:1%20562%20867%205309" target="_self" style="margin: 0 20px 0 0">
<span class="qodef-icon-element icon_phone" style="font-size: 14px"></span> <span class="qodef-icon-text ">1 562 867 5309</span> </a>
<a class="qodef-icon-widget-holder" href="https://www.google.rs/maps/place/Charging+Bull/@40.7055242,-74.0133806,20z/data=!4m5!3m4!1s0x0:0xc7db393ae1eff521!8m2!3d40.7055537!4d-74.0134436" target="_blank" style="margin: 0 20px 0 0">
<span class="qodef-icon-element icon_pin_alt" style="font-size: 14px"></span> <span class="qodef-icon-text ">Broadway &amp; Morris St, New York</span> </a>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 13px;margin: 0 16px 0 0;" href="https://twitter.com/QodeInteractive" target="_blank">
<span class="qodef-social-icon-widget fab fa-twitter      "></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 13px;margin: 0 16px 0 0;" href="https://www.pinterest.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-pinterest-p      "></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 13px;margin: 0 16px 0 0;" href="https://www.facebook.com/QodeInteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-facebook-f      "></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" style="font-size: 13px;margin: 0 35px 0 0;" href="https://www.instagram.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget fab fa-instagram      "></span> </a>
<div id="custom_html-2" class="widget_text widget widget_custom_html qodef-top-bar-widget"><div class="textwidget custom-html-widget"><div class="widget widget_icl_lang_sel_widget">
<div class="wpml-ls-sidebars-qodef-header-widget-area-one wpml-ls wpml-ls-legacy-dropdown js-wpml-ls-legacy-dropdown" id="lang_sel">
<ul>
<li tabindex="0" class="wpml-ls-slot-qodef-header-widget-area-one wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-first-item wpml-ls-item-legacy-dropdown">
<a href="#" class="js-wpml-ls-item-toggle wpml-ls-item-toggle lang_sel_sel icl-en"><span class="wpml-ls-native icl_lang_sel_native">English</span></a>
<ul class="wpml-ls-sub-menu">
<li class="icl-fr wpml-ls-slot-qodef-header-widget-area-one wpml-ls-item wpml-ls-item-fr">
<a href="#" class="wpml-ls-link"><span class="wpml-ls-display icl_lang_sel_translated">French</span></a>
</li>
<li class="icl-de wpml-ls-slot-qodef-header-widget-area-one wpml-ls-item wpml-ls-item-de">
<a href="#" class="wpml-ls-link"><span class="wpml-ls-display icl_lang_sel_translated">German</span></a>
</li>
<li class="icl-it wpml-ls-slot-qodef-header-widget-area-one wpml-ls-item wpml-ls-item-it wpml-ls-last-item">
<a href="#" class="wpml-ls-link"><span class="wpml-ls-display icl_lang_sel_translated">Italian</span></a>
</li>
</ul>
</li>
</ul>
</div></div></div></div><div class="widget qodef-login-register-widget qodef-user-not-logged-in"><a href="#" class="qodef-login-opener">
<svg version="1.1" x="0px" y="0px" viewBox="0 0 23 23" enable-background="new 0 0 23 23" xml:space="preserve">
<g>
<path fill="currentColor" d="M11.5,14.1c-2.2,0-4-1.8-4-4c0-2.2,1.8-4,4-4s4,1.8,4,4C15.5,12.3,13.7,14.1,11.5,14.1z M11.5,7.3
            c-1.6,0-2.8,1.3-2.8,2.8c0,1.6,1.3,2.8,2.8,2.8s2.8-1.3,2.8-2.8C14.3,8.5,13,7.3,11.5,7.3z" />
<path fill="currentColor" d="M11.5,23c-3.1,0-5.9-1.2-8.1-3.4c-2.2-2.2-3.4-5-3.4-8.1s1.2-5.9,3.4-8.1c2.2-2.2,5-3.4,8.1-3.4
            s5.9,1.2,8.1,3.4c2.2,2.2,3.4,5,3.4,8.1s-1.2,5.9-3.4,8.1C17.4,21.8,14.5,23,11.5,23z M11.5,1.2C5.8,1.2,1.2,5.9,1.2,11.5
            s4.6,10.3,10.3,10.3s10.3-4.6,10.3-10.3S17.1,1.2,11.5,1.2z" />
<path fill="currentColor" d="M11.5,23c-1.5,0-2.9-0.3-4.2-0.8c-0.2-0.1-0.4-0.3-0.4-0.6v-5.3c0-1.8,1.5-3.3,3.3-3.3h2.6
            c1.8,0,3.3,1.5,3.3,3.3v5.3c0,0.2-0.1,0.5-0.4,0.6C14.4,22.7,12.9,23,11.5,23z M8.1,21.2c1.1,0.4,2.2,0.6,3.4,0.6s2.3-0.2,3.4-0.6
            v-4.9c0-1.2-0.9-2.1-2.1-2.1h-2.6c-1.2,0-2.1,0.9-2.1,2.1V21.2z" />
</g>
</svg>
</a></div> </div>
</div>
</div>
</div>
<div class="qodef-fullscreen-search-holder">
<a class="qodef-search-close qodef-search-close-svg-path" href="javascript:void(0)">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="18px" height="18px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
<line fill="none" x1="5.4" y1="15.6" x2="5.4" y2="15.6" />
<line fill="none" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" x1="0.5" y1="0.6" x2="19.4" y2="19.4" />
<line fill="none" stroke="#fff" stroke-width="1.5" stroke-miterlimit="10" x1="19.4" y1="0.6" x2="0.6" y2="19.4" />
</svg> </a>
<div class="qodef-fullscreen-search-table">
<div class="qodef-fullscreen-search-cell">
<div class="qodef-fullscreen-search-inner">
<form action="https://setsail.qodeinteractive.com/" class="qodef-fullscreen-search-form" method="get">
<div class="qodef-form-holder">
<div class="qodef-form-holder-inner">
<div class="qodef-field-holder qodef-flp-search-field-holder" data-post-type="tour-item">
<input type="text" class="qodef-search-field" placeholder="Search..." name="s" autocomplete="off" />
<button type="submit" class="qodef-search-submit">Find Now</button>
</div>
<div class="qodef-flp-search-results"></div>
<input type="hidden" id="qodef_fullscreen_search_post_types_nonce" name="qodef_fullscreen_search_post_types_nonce" value="5866189135" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" /> </div>
</div>
</form>
</div>
</div>
</div>
</div>
<header class="qodef-page-header">
<div class="qodef-menu-area qodef-menu-center">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<div class="qodef-logo-wrapper">
<a itemprop="url" href="https://setsail.qodeinteractive.com/" style="height: 48px;">
<img itemprop="image" class="qodef-normal-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo.png" width="301" height="96" alt="logo" />
<img itemprop="image" class="qodef-dark-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo.png" width="301" height="96" alt="dark logo" /> <img itemprop="image" class="qodef-light-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo-white.png" width="301" height="96" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<nav class="qodef-main-menu qodef-drop-down qodef-default-nav">
<ul id="menu-main-menu" class="clearfix"><li id="nav-menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Home</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-642" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://setsail.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Travel Agency</span></span></a></li>
<li id="nav-menu-item-957" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/winter-holidays/" class=""><span class="item_outer"><span class="item_text">Winter Holidays</span></span></a></li>
<li id="nav-menu-item-856" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/exotic-destinations/" class=""><span class="item_outer"><span class="item_text">Exotic Destinations</span></span></a></li>
<li id="nav-menu-item-645" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/summer-holidays/" class=""><span class="item_outer"><span class="item_text">Summer Holidays</span></span></a></li>
<li id="nav-menu-item-963" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/city-tours/" class=""><span class="item_outer"><span class="item_text">City Tours</span></span></a></li>
<li id="nav-menu-item-985" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/new-year-trips/" class=""><span class="item_outer"><span class="item_text">New Year Trips</span></span></a></li>
<li id="nav-menu-item-3014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destinations-carousel/" class=""><span class="item_outer"><span class="item_text">Destinations Carousel</span></span></a></li>
<li id="nav-menu-item-1072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/wine-tours/" class=""><span class="item_outer"><span class="item_text">Wine Tours</span></span></a></li>
<li id="nav-menu-item-4555" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/vacation-showcase/" class=""><span class="item_outer"><span class="item_text">Vacation Showcase</span></span></a></li>
<li id="nav-menu-item-2132" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-527" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
<li id="nav-menu-item-1198" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_text">What We Offer</span></span></a></li>
<li id="nav-menu-item-622" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/our-team/" class=""><span class="item_outer"><span class="item_text">Our Team</span></span></a></li>
<li id="nav-menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/get-in-touch/" class=""><span class="item_outer"><span class="item_text">Get In Touch</span></span></a></li>
<li id="nav-menu-item-775" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span></span></a></li>
<li id="nav-menu-item-1317" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">FAQ Page</span></span></a></li>
<li id="nav-menu-item-1316" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span></span></a></li>
<li id="nav-menu-item-1627" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/404-error-page/" class=""><span class="item_outer"><span class="item_text">Error Page</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-5106" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Destinations</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-3013" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span></span></a></li>
<li id="nav-menu-item-5109" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-slider/" class=""><span class="item_outer"><span class="item_text">Destination Slider</span></span></a></li>
<li id="nav-menu-item-4786" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://setsail.qodeinteractive.com/destinations/taiwan/" class=""><span class="item_outer"><span class="item_text">Destination Item</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-1644" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Tours</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-4556" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/" class=""><span class="item_outer"><span class="item_text">Standard List</span></span></a></li>
<li id="nav-menu-item-3812" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=gallery" class=""><span class="item_outer"><span class="item_text">Gallery List</span></span></a></li>
<li id="nav-menu-item-3810" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=list" class=""><span class="item_outer"><span class="item_text">Split List</span></span></a></li>
<li id="nav-menu-item-1632" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://setsail.qodeinteractive.com/tour-item/sydney-opera/" class=""><span class="item_outer"><span class="item_text">Tour Item</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-34" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-347" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/blog-masonry/" class=""><span class="item_outer"><span class="item_text">Blog Masonry</span></span></a></li>
<li id="nav-menu-item-2214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog Standard</span></span></a>
<ul>
<li id="nav-menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span></span></a></li>
<li id="nav-menu-item-1634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span></span></a></li>
<li id="nav-menu-item-2213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/without-sidebar/" class=""><span class="item_outer"><span class="item_text">Without Sidebar</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-350" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Post Types</span></span></a>
<ul>
<li id="nav-menu-item-351" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/beautiful-china/" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-354" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/travel-in-europe/" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-355" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/stunning-greece/" class=""><span class="item_outer"><span class="item_text">Link</span></span></a></li>
<li id="nav-menu-item-353" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/lifetime-journey/" class=""><span class="item_outer"><span class="item_text">Quote</span></span></a></li>
<li id="nav-menu-item-357" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/visit-thailand-bali-and-china/" class=""><span class="item_outer"><span class="item_text">Video</span></span></a></li>
<li id="nav-menu-item-356" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/the-sound-of-our-jungle/" class=""><span class="item_outer"><span class="item_text">Audio</span></span></a></li>
<li id="nav-menu-item-2837" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/adventure-is-here/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_text">Product List</span></span></a></li>
<li id="nav-menu-item-360" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/product/modern-hat/" class=""><span class="item_outer"><span class="item_text">Product Single</span></span></a></li>
<li id="nav-menu-item-468" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Layouts</span></span></a>
<ul>
<li id="nav-menu-item-467" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span></span></a></li>
<li id="nav-menu-item-465" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span></span></a></li>
<li id="nav-menu-item-466" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/full-width/" class=""><span class="item_outer"><span class="item_text">Full Width</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-23" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span></span></a>
<ul>
<li id="nav-menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span></span></a></li>
<li id="nav-menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span></span></a></li>
<li id="nav-menu-item-25" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has_sub wide"><a href="https://setsail.qodeinteractive.com/elements/" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Elements</span><i class="qodef-menu-arrow arrow_carrot-right"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-248" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Featured</span></span></a>
<ul>
<li id="nav-menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-list/" class=""><span class="item_outer"><span class="item_text">Tour List</span></span></a></li>
<li id="nav-menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-carousel/" class=""><span class="item_outer"><span class="item_text">Tour Carousel</span></span></a></li>
<li id="nav-menu-item-3597" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tours-filter/" class=""><span class="item_outer"><span class="item_text">Tours Filter</span></span></a></li>
<li id="nav-menu-item-3015" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-with-tours/" class=""><span class="item_outer"><span class="item_text">Destination With Tours</span></span></a></li>
<li id="nav-menu-item-3536" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destinations-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span></span></a></li>
<li id="nav-menu-item-3603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-fullscreen-slider/" class=""><span class="item_outer"><span class="item_text">Destination Fullscreen Slider</span></span></a></li>
<li id="nav-menu-item-1625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/fullscreen-sections/" class=""><span class="item_outer"><span class="item_text">Fullscreen Sections</span></span></a></li>
<li id="nav-menu-item-3596" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/reviews-carousel/" class=""><span class="item_outer"><span class="item_text">Reviews Carousel</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-246" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Presentation</span></span></a>
<ul>
<li id="nav-menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span></span></a></li>
<li id="nav-menu-item-1357" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span></span></a></li>
<li id="nav-menu-item-2384" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/shop-list/" class=""><span class="item_outer"><span class="item_text">Shop List</span></span></a></li>
<li id="nav-menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/testimonials/" class=""><span class="item_outer"><span class="item_text">Testimonials</span></span></a></li>
<li id="nav-menu-item-1602" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/banner/" class=""><span class="item_outer"><span class="item_text">Banner</span></span></a></li>
<li id="nav-menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span></span></a></li>
<li id="nav-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/parallax-section/" class=""><span class="item_outer"><span class="item_text">Parallax Section</span></span></a></li>
<li id="nav-menu-item-1604" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/video-button/" class=""><span class="item_outer"><span class="item_text">Video Button</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-241" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Classic</span></span></a>
<ul>
<li id="nav-menu-item-1356" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/accordions/" class=""><span class="item_outer"><span class="item_text">Accordions</span></span></a></li>
<li id="nav-menu-item-1608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span></span></a></li>
<li id="nav-menu-item-1358" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span></span></a></li>
<li id="nav-menu-item-1607" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span></span></a></li>
<li id="nav-menu-item-1606" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span></span></a></li>
<li id="nav-menu-item-1360" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span></span></a></li>
<li id="nav-menu-item-1626" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/countdown/" class=""><span class="item_outer"><span class="item_text">Countdown</span></span></a></li>
<li id="nav-menu-item-1359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/counters/" class=""><span class="item_outer"><span class="item_text">Counters</span></span></a></li>
<li id="nav-menu-item-1603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/call-to-action/" class=""><span class="item_outer"><span class="item_text">Call To Action</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-27" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Typography</span></span></a>
<ul>
<li id="nav-menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span></span></a></li>
<li id="nav-menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span></span></a></li>
<li id="nav-menu-item-1463" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/section-title/" class=""><span class="item_outer"><span class="item_text">Section Title</span></span></a></li>
<li id="nav-menu-item-1613" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span></span></a></li>
<li id="nav-menu-item-1612" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/dropcaps/" class=""><span class="item_outer"><span class="item_text">Dropcaps</span></span></a></li>
<li id="nav-menu-item-1611" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/highlights/" class=""><span class="item_outer"><span class="item_text">Highlights</span></span></a></li>
<li id="nav-menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon with text</span></span></a></li>
<li id="nav-menu-item-1610" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span></span></a></li>
<li id="nav-menu-item-1609" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul> </nav>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<div class="qodef-shopping-cart-holder" style="margin: 0 20px 0 0">
<div class="qodef-shopping-cart-inner">
<a itemprop="url" class="qodef-header-cart qodef-header-cart-svg-path" href="https://setsail.qodeinteractive.com/cart/">
<span class="qodef-cart-icon"><svg version="1.1" x="0px" y="0px" width="20" viewBox="0 0 20 17" enable-background="new 0 0 20 17" xml:space="preserve">
<g>
<path stroke-width="0.3" stroke-miterlimit="10" d="M3.9,8.9H1.4c-0.7,0-1.2-0.5-1.2-1.2V6.8
		c0-0.7,0.5-1.2,1.2-1.2h2.9v0.8H1.4C1.2,6.4,1,6.6,1,6.8v0.8c0,0.2,0.2,0.4,0.4,0.4h2.4V8.9z" />
</g>
<g>
<rect x="6.7" y="5.6" stroke-width="0.3" stroke-miterlimit="10" width="6.5" height="0.8" />
</g>
<g>
<rect x="2" y="8.1" stroke-width="0.3" stroke-miterlimit="10" width="15.1" height="0.8" />
</g>
<g>
<path stroke-width="0.3" stroke-miterlimit="10" d="M18.6,8.9h-2.4V8.1h2.4c0.2,0,0.4-0.2,0.4-0.4V6.8
		c0-0.2-0.2-0.4-0.4-0.4h-2.9V5.6h2.9c0.7,0,1.2,0.5,1.2,1.2v0.8C19.8,8.3,19.2,8.9,18.6,8.9z" />
</g>
<g>
<path stroke-width="0.3" stroke-miterlimit="10" d="M15.5,16.2H4.5c-0.8,0-1.4-0.5-1.6-1.3L1.4,8.6l0.8-0.2
		l1.4,6.4c0.1,0.4,0.4,0.6,0.8,0.6h11.1c0.4,0,0.7-0.3,0.8-0.6l1.4-6.4l0.8,0.2l-1.4,6.4C17,15.7,16.3,16.2,15.5,16.2z" />
</g>
<g>
<path stroke-width="0.3" stroke-miterlimit="10" d="M5.1,7.7c-0.1,0-0.1,0-0.2,0C4.7,7.5,4.6,7.3,4.7,7.1L7.2,1
		c0.1-0.2,0.3-0.3,0.5-0.2C7.9,0.8,8,1.1,7.9,1.3L5.5,7.4C5.4,7.6,5.3,7.7,5.1,7.7z" />
</g>
<g>
<path stroke-width="0.3" stroke-miterlimit="10" d="M14.9,7.7c-0.2,0-0.3-0.1-0.4-0.3l-2.4-6.1
		c-0.1-0.2,0-0.4,0.2-0.5c0.2-0.1,0.4,0,0.5,0.2l2.4,6.1c0.1,0.2,0,0.4-0.2,0.5C15,7.6,14.9,7.7,14.9,7.7z" />
</g>
</svg></span>
</a>
<div class="qodef-shopping-cart-dropdown">
<ul>
<li class="qodef-empty-cart">No products in the cart.</li>
</ul>
</div>
</div>
</div>
<a style="margin: 0 20px 0 0;" class="qodef-search-opener qodef-icon-has-hover qodef-search-opener-svg-path" href="javascript:void(0)">
<span class="qodef-search-opener-wrapper">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="20px" height="19px" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
<circle fill="none" stroke-width="1.5" stroke-miterlimit="10" cx="10.9" cy="9.5" r="8.4" />
<line fill="none" x1="5.4" y1="15.6" x2="5.4" y2="15.6" />
<line stroke-width="1.5" stroke-miterlimit="10" x1="5.3" y1="15.2" x2="0.6" y2="19.4" />
</svg> </span>
</a>
<a class="qodef-side-menu-button-opener qodef-icon-has-hover qodef-side-menu-button-opener-svg-path" href="javascript:void(0)">
<span class="qodef-side-menu-icon">
<svg class="qodef-setsail-burger" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19px" height="17px" viewBox="0 0 26 20" enable-background="new 0 0 26 20" xml:space="preserve">
<rect x="10.5" width="13.7" height="2.4" />
<rect x="8" y="8.8" width="16.2" height="2.4" />
<rect x="1.7" y="17.6" width="22.5" height="2.4" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
<div class="qodef-sticky-header">
<div class="qodef-sticky-holder qodef-menu-center">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<div class="qodef-logo-wrapper">
<a itemprop="url" href="https://setsail.qodeinteractive.com/" style="height: 48px;">
<img itemprop="image" class="qodef-normal-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo.png" width="301" height="96" alt="logo" />
<img itemprop="image" class="qodef-dark-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo.png" width="301" height="96" alt="dark logo" /> <img itemprop="image" class="qodef-light-logo" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo-white.png" width="301" height="96" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<nav class="qodef-main-menu qodef-drop-down qodef-sticky-nav">
<ul id="menu-main-menu-1" class="clearfix"><li id="sticky-nav-menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Home</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-642" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://setsail.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Travel Agency</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-957" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/winter-holidays/" class=""><span class="item_outer"><span class="item_text">Winter Holidays</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-856" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/exotic-destinations/" class=""><span class="item_outer"><span class="item_text">Exotic Destinations</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-645" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/summer-holidays/" class=""><span class="item_outer"><span class="item_text">Summer Holidays</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-963" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/city-tours/" class=""><span class="item_outer"><span class="item_text">City Tours</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-985" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/new-year-trips/" class=""><span class="item_outer"><span class="item_text">New Year Trips</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destinations-carousel/" class=""><span class="item_outer"><span class="item_text">Destinations Carousel</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/wine-tours/" class=""><span class="item_outer"><span class="item_text">Wine Tours</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-4555" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/vacation-showcase/" class=""><span class="item_outer"><span class="item_text">Vacation Showcase</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2132" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-527" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1198" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_text">What We Offer</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-622" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/our-team/" class=""><span class="item_outer"><span class="item_text">Our Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/get-in-touch/" class=""><span class="item_outer"><span class="item_text">Get In Touch</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-775" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1317" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">FAQ Page</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1316" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1627" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/404-error-page/" class=""><span class="item_outer"><span class="item_text">Error Page</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-5106" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Destinations</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-3013" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-5109" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-slider/" class=""><span class="item_outer"><span class="item_text">Destination Slider</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-4786" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://setsail.qodeinteractive.com/destinations/taiwan/" class=""><span class="item_outer"><span class="item_text">Destination Item</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-1644" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Tours</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-4556" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/" class=""><span class="item_outer"><span class="item_text">Standard List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3812" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=gallery" class=""><span class="item_outer"><span class="item_text">Gallery List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3810" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=list" class=""><span class="item_outer"><span class="item_text">Split List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1632" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://setsail.qodeinteractive.com/tour-item/sydney-opera/" class=""><span class="item_outer"><span class="item_text">Tour Item</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-34" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-347" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/blog-masonry/" class=""><span class="item_outer"><span class="item_text">Blog Masonry</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog Standard</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/without-sidebar/" class=""><span class="item_outer"><span class="item_text">Without Sidebar</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-350" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Post Types</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-351" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/beautiful-china/" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-354" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/travel-in-europe/" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-355" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/stunning-greece/" class=""><span class="item_outer"><span class="item_text">Link</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-353" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/lifetime-journey/" class=""><span class="item_outer"><span class="item_text">Quote</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-357" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/visit-thailand-bali-and-china/" class=""><span class="item_outer"><span class="item_text">Video</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-356" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/the-sound-of-our-jungle/" class=""><span class="item_outer"><span class="item_text">Audio</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2837" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/adventure-is-here/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/" class=""><span class="item_outer"><span class="item_text">Product List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-360" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/product/modern-hat/" class=""><span class="item_outer"><span class="item_text">Product Single</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-468" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Layouts</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-467" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-465" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-466" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/full-width/" class=""><span class="item_outer"><span class="item_text">Full Width</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-23" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-25" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has_sub wide"><a href="https://setsail.qodeinteractive.com/elements/" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Elements</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-248" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Featured</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-list/" class=""><span class="item_outer"><span class="item_text">Tour List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-carousel/" class=""><span class="item_outer"><span class="item_text">Tour Carousel</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3597" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tours-filter/" class=""><span class="item_outer"><span class="item_text">Tours Filter</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3015" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-with-tours/" class=""><span class="item_outer"><span class="item_text">Destination With Tours</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3536" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destinations-list/" class=""><span class="item_outer"><span class="item_text">Destination List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-fullscreen-slider/" class=""><span class="item_outer"><span class="item_text">Destination Fullscreen Slider</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/fullscreen-sections/" class=""><span class="item_outer"><span class="item_text">Fullscreen Sections</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3596" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/reviews-carousel/" class=""><span class="item_outer"><span class="item_text">Reviews Carousel</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-246" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Presentation</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1357" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2384" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/shop-list/" class=""><span class="item_outer"><span class="item_text">Shop List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/testimonials/" class=""><span class="item_outer"><span class="item_text">Testimonials</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1602" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/banner/" class=""><span class="item_outer"><span class="item_text">Banner</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/parallax-section/" class=""><span class="item_outer"><span class="item_text">Parallax Section</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1604" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/video-button/" class=""><span class="item_outer"><span class="item_text">Video Button</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-241" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Classic</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1356" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/accordions/" class=""><span class="item_outer"><span class="item_text">Accordions</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1358" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1607" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1606" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1360" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1626" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/countdown/" class=""><span class="item_outer"><span class="item_text">Countdown</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/counters/" class=""><span class="item_outer"><span class="item_text">Counters</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/call-to-action/" class=""><span class="item_outer"><span class="item_text">Call To Action</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-27" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Typography</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1463" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/section-title/" class=""><span class="item_outer"><span class="item_text">Section Title</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1613" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1612" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/dropcaps/" class=""><span class="item_outer"><span class="item_text">Dropcaps</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1611" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/highlights/" class=""><span class="item_outer"><span class="item_text">Highlights</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon with text</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1610" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1609" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<a style="margin: 0 17px 0 0;" class="qodef-search-opener qodef-icon-has-hover qodef-search-opener-svg-path" href="javascript:void(0)">
<span class="qodef-search-opener-wrapper">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="20px" height="19px" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
<circle fill="none" stroke-width="1.5" stroke-miterlimit="10" cx="10.9" cy="9.5" r="8.4" />
<line fill="none" x1="5.4" y1="15.6" x2="5.4" y2="15.6" />
<line stroke-width="1.5" stroke-miterlimit="10" x1="5.3" y1="15.2" x2="0.6" y2="19.4" />
</svg> </span>
</a>
<a class="qodef-side-menu-button-opener qodef-icon-has-hover qodef-side-menu-button-opener-svg-path" href="javascript:void(0)">
<span class="qodef-side-menu-icon">
<svg class="qodef-setsail-burger" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19px" height="17px" viewBox="0 0 26 20" enable-background="new 0 0 26 20" xml:space="preserve">
<rect x="10.5" width="13.7" height="2.4" />
<rect x="8" y="8.8" width="16.2" height="2.4" />
<rect x="1.7" y="17.6" width="22.5" height="2.4" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
</div>
</header>
<header class="qodef-mobile-header">
<div class="qodef-mobile-header-inner">
<div class="qodef-mobile-header-holder">
<div class="qodef-grid">
<div class="qodef-vertical-align-containers">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<div class="qodef-mobile-menu-opener qodef-mobile-menu-opener-svg-path">
<a href="javascript:void(0)">
<span class="qodef-mobile-menu-icon">
<svg class="qodef-setsail-burger" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19px" height="17px" viewBox="0 0 26 20" enable-background="new 0 0 26 20" xml:space="preserve">
<rect x="10.5" width="13.7" height="2.4" />
<rect x="8" y="8.8" width="16.2" height="2.4" />
<rect x="1.7" y="17.6" width="22.5" height="2.4" />
</svg> </span>
</a>
</div>
</div>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<div class="qodef-mobile-logo-wrapper">
<a itemprop="url" href="https://setsail.qodeinteractive.com/" style="height: 36px">
<img itemprop="image" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo-mobile-img.png" width="230" height="73" alt="Mobile Logo" />
</a>
</div>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<div class="widget qodef-login-register-widget qodef-user-not-logged-in"><a href="#" class="qodef-login-opener">
<svg version="1.1" x="0px" y="0px" viewBox="0 0 23 23" enable-background="new 0 0 23 23" xml:space="preserve">
<g>
<path fill="currentColor" d="M11.5,14.1c-2.2,0-4-1.8-4-4c0-2.2,1.8-4,4-4s4,1.8,4,4C15.5,12.3,13.7,14.1,11.5,14.1z M11.5,7.3
            c-1.6,0-2.8,1.3-2.8,2.8c0,1.6,1.3,2.8,2.8,2.8s2.8-1.3,2.8-2.8C14.3,8.5,13,7.3,11.5,7.3z" />
<path fill="currentColor" d="M11.5,23c-3.1,0-5.9-1.2-8.1-3.4c-2.2-2.2-3.4-5-3.4-8.1s1.2-5.9,3.4-8.1c2.2-2.2,5-3.4,8.1-3.4
            s5.9,1.2,8.1,3.4c2.2,2.2,3.4,5,3.4,8.1s-1.2,5.9-3.4,8.1C17.4,21.8,14.5,23,11.5,23z M11.5,1.2C5.8,1.2,1.2,5.9,1.2,11.5
            s4.6,10.3,10.3,10.3s10.3-4.6,10.3-10.3S17.1,1.2,11.5,1.2z" />
<path fill="currentColor" d="M11.5,23c-1.5,0-2.9-0.3-4.2-0.8c-0.2-0.1-0.4-0.3-0.4-0.6v-5.3c0-1.8,1.5-3.3,3.3-3.3h2.6
            c1.8,0,3.3,1.5,3.3,3.3v5.3c0,0.2-0.1,0.5-0.4,0.6C14.4,22.7,12.9,23,11.5,23z M8.1,21.2c1.1,0.4,2.2,0.6,3.4,0.6s2.3-0.2,3.4-0.6
            v-4.9c0-1.2-0.9-2.1-2.1-2.1h-2.6c-1.2,0-2.1,0.9-2.1,2.1V21.2z" />
</g>
</svg>
</a></div> </div>
</div>
</div>
</div>
</div>
</div>
<nav class="qodef-mobile-nav" role="navigation" aria-label="Mobile Menu">
<div class="qodef-grid">
<ul id="menu-main-menu-2" class=""><li id="mobile-menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Home</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-642" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://setsail.qodeinteractive.com/" class=""><span>Travel Agency</span></a></li>
<li id="mobile-menu-item-957" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/winter-holidays/" class=""><span>Winter Holidays</span></a></li>
<li id="mobile-menu-item-856" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/exotic-destinations/" class=""><span>Exotic Destinations</span></a></li>
<li id="mobile-menu-item-645" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/summer-holidays/" class=""><span>Summer Holidays</span></a></li>
<li id="mobile-menu-item-963" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/city-tours/" class=""><span>City Tours</span></a></li>
<li id="mobile-menu-item-985" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/new-year-trips/" class=""><span>New Year Trips</span></a></li>
<li id="mobile-menu-item-3014" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destinations-carousel/" class=""><span>Destinations Carousel</span></a></li>
<li id="mobile-menu-item-1072" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/wine-tours/" class=""><span>Wine Tours</span></a></li>
<li id="mobile-menu-item-4555" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/vacation-showcase/" class=""><span>Vacation Showcase</span></a></li>
<li id="mobile-menu-item-2132" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/landing/" class=""><span>Landing</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-527" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Pages</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
<li id="mobile-menu-item-1198" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/what-we-offer/" class=""><span>What We Offer</span></a></li>
<li id="mobile-menu-item-622" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/our-team/" class=""><span>Our Team</span></a></li>
<li id="mobile-menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/get-in-touch/" class=""><span>Get In Touch</span></a></li>
<li id="mobile-menu-item-775" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/contact-us/" class=""><span>Contact Us</span></a></li>
<li id="mobile-menu-item-1317" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/faq-page/" class=""><span>FAQ Page</span></a></li>
<li id="mobile-menu-item-1316" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/coming-soon/" class=""><span>Coming Soon</span></a></li>
<li id="mobile-menu-item-1627" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/404-error-page/" class=""><span>Error Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-5106" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Destinations</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-3013" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-list/" class=""><span>Destination List</span></a></li>
<li id="mobile-menu-item-5109" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/destination-slider/" class=""><span>Destination Slider</span></a></li>
<li id="mobile-menu-item-4786" class="menu-item menu-item-type-post_type menu-item-object-destinations "><a href="https://setsail.qodeinteractive.com/destinations/taiwan/" class=""><span>Destination Item</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1644" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Tours</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-4556" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/" class=""><span>Standard List</span></a></li>
<li id="mobile-menu-item-3812" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=gallery" class=""><span>Gallery List</span></a></li>
<li id="mobile-menu-item-3810" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/tours-search-page/?view_type=list" class=""><span>Split List</span></a></li>
<li id="mobile-menu-item-1632" class="menu-item menu-item-type-post_type menu-item-object-tour-item "><a href="https://setsail.qodeinteractive.com/tour-item/sydney-opera/" class=""><span>Tour Item</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-34" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Blog</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-347" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/blog-masonry/" class=""><span>Blog Masonry</span></a></li>
<li id="mobile-menu-item-2214" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Blog Standard</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/right-sidebar/" class=""><span>Right Sidebar</span></a></li>
<li id="mobile-menu-item-1634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/left-sidebar/" class=""><span>Left Sidebar</span></a></li>
<li id="mobile-menu-item-2213" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/without-sidebar/" class=""><span>Without Sidebar</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-350" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Post Types</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-351" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/beautiful-china/" class=""><span>Standard</span></a></li>
<li id="mobile-menu-item-354" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/travel-in-europe/" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-355" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/stunning-greece/" class=""><span>Link</span></a></li>
<li id="mobile-menu-item-353" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/lifetime-journey/" class=""><span>Quote</span></a></li>
<li id="mobile-menu-item-357" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/visit-thailand-bali-and-china/" class=""><span>Video</span></a></li>
<li id="mobile-menu-item-356" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/the-sound-of-our-jungle/" class=""><span>Audio</span></a></li>
<li id="mobile-menu-item-2837" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://setsail.qodeinteractive.com/adventure-is-here/" class=""><span>No Sidebar</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/" class=""><span>Product List</span></a></li>
<li id="mobile-menu-item-360" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://setsail.qodeinteractive.com/product/modern-hat/" class=""><span>Product Single</span></a></li>
<li id="mobile-menu-item-468" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop Layouts</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-467" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/three-columns/" class=""><span>Three Columns</span></a></li>
<li id="mobile-menu-item-465" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/four-columns/" class=""><span>Four Columns</span></a></li>
<li id="mobile-menu-item-466" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/shop/full-width/" class=""><span>Full Width</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-23" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop Pages</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/my-account/" class=""><span>My account</span></a></li>
<li id="mobile-menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/cart/" class=""><span>Cart</span></a></li>
<li id="mobile-menu-item-25" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/checkout/" class=""><span>Checkout</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has_sub"><h6><span>Elements</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-248" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Featured</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-list/" class=""><span>Tour List</span></a></li>
<li id="mobile-menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tour-carousel/" class=""><span>Tour Carousel</span></a></li>
<li id="mobile-menu-item-3597" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tours-filter/" class=""><span>Tours Filter</span></a></li>
<li id="mobile-menu-item-3015" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-with-tours/" class=""><span>Destination With Tours</span></a></li>
<li id="mobile-menu-item-3536" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destinations-list/" class=""><span>Destination List</span></a></li>
<li id="mobile-menu-item-3603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/destination-fullscreen-slider/" class=""><span>Destination Fullscreen Slider</span></a></li>
<li id="mobile-menu-item-1625" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/fullscreen-sections/" class=""><span>Fullscreen Sections</span></a></li>
<li id="mobile-menu-item-3596" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/reviews-carousel/" class=""><span>Reviews Carousel</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-246" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Presentation</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/team/" class=""><span>Team</span></a></li>
<li id="mobile-menu-item-1357" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blog-list/" class=""><span>Blog List</span></a></li>
<li id="mobile-menu-item-2384" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/shop-list/" class=""><span>Shop List</span></a></li>
<li id="mobile-menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/testimonials/" class=""><span>Testimonials</span></a></li>
<li id="mobile-menu-item-1602" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/banner/" class=""><span>Banner</span></a></li>
<li id="mobile-menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/clients/" class=""><span>Clients</span></a></li>
<li id="mobile-menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/parallax-section/" class=""><span>Parallax Section</span></a></li>
<li id="mobile-menu-item-1604" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/video-button/" class=""><span>Video Button</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-241" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Classic</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1356" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/accordions/" class=""><span>Accordions</span></a></li>
<li id="mobile-menu-item-1608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/tabs/" class=""><span>Tabs</span></a></li>
<li id="mobile-menu-item-1358" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/buttons/" class=""><span>Buttons</span></a></li>
<li id="mobile-menu-item-1607" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/google-maps/" class=""><span>Google Maps</span></a></li>
<li id="mobile-menu-item-1606" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/contact-form/" class=""><span>Contact Form</span></a></li>
<li id="mobile-menu-item-1360" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/progress-bar/" class=""><span>Progress Bar</span></a></li>
<li id="mobile-menu-item-1626" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/countdown/" class=""><span>Countdown</span></a></li>
<li id="mobile-menu-item-1359" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/counters/" class=""><span>Counters</span></a></li>
<li id="mobile-menu-item-1603" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/call-to-action/" class=""><span>Call To Action</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-27" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Typography</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow arrow_carrot-right"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/headings/" class=""><span>Headings</span></a></li>
<li id="mobile-menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/columns/" class=""><span>Columns</span></a></li>
<li id="mobile-menu-item-1463" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/section-title/" class=""><span>Section Title</span></a></li>
<li id="mobile-menu-item-1613" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/blockquote/" class=""><span>Blockquote</span></a></li>
<li id="mobile-menu-item-1612" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/dropcaps/" class=""><span>Dropcaps</span></a></li>
<li id="mobile-menu-item-1611" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/highlights/" class=""><span>Highlights</span></a></li>
<li id="mobile-menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/icon-with-text/" class=""><span>Icon with text</span></a></li>
<li id="mobile-menu-item-1610" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/separators/" class=""><span>Separators</span></a></li>
<li id="mobile-menu-item-1609" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://setsail.qodeinteractive.com/elements/custom-font/" class=""><span>Custom Font</span></a></li>
</ul>
</li>
</ul>
</li>
</ul> </div>
</nav>
</div>
</header>
<a id='qodef-back-to-top' href='#'>
<span class="qodef-btt-text">TOP</span>
</a>
<div class="qodef-content" style="margin-top: -80px">
<div class="qodef-content-inner"><div class="qodef-page-not-found">
<div class="qodef-404-title-image">
<img src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/404-error-page-img-1.png" alt="404 Title Image" />
</div>
<h1 class="qodef-404-title">
</h1>
<p class="qodef-404-text qodef-grid-col-8">
Oops! The page you are looking for does not exist. It might have been moved or deleted. Return to our home page.	</p>
<a itemprop="url" href="https://setsail.qodeinteractive.com/" target="_self" class="qodef-btn qodef-btn-medium qodef-btn-solid"> <span class="qodef-btn-text">Back to home</span> </a></div>
</div> 
</div> 
<footer class="qodef-page-footer ">
<div class="qodef-footer-top-holder">
<div class="qodef-footer-top-inner qodef-full-width">
<div class="qodef-grid-row qodef-footer-top-alignment-left">
<div class="qodef-column-content qodef-grid-col-3">
<div id="media_image-2" class="widget qodef-footer-column-1 widget_media_image"><a href="https://setsail.qodeinteractive.com/"><img width="263" height="84" src="https://setsail.qodeinteractive.com/wp-content/uploads/2018/09/logo-footer.png" class="image wp-image-4716  attachment-full size-full" alt="d" loading="lazy" style="max-width: 100%; height: auto;" /></a></div><div class="widget qodef-custom-font-widget"><p class="qodef-custom-font-holder  qodef-cf-3633  " style="font-family: Poppins;font-size: 17px;line-height: 1.64em;font-weight: 400;color: #a9a9a9;margin: 0 0 17px 0" data-item-class="qodef-cf-3633">
Lorem ipsum dolor sit ametco nsec te tuer adipiscing elitae</p></div>
<a class="qodef-icon-widget-holder" href="/cdn-cgi/l/email-protection#3447514047555d5874455b50511a575b59" target="_self" style="margin: 0 0 4px 0">
<span class="qodef-icon-element icon_mail_alt" style="font-size: 14px"></span> <span class="qodef-icon-text "><span class="__cf_email__" data-cfemail="1261776661737b7e52637d76773c717d7f">[email&#160;protected]</span></span> </a>
<a class="qodef-icon-widget-holder" href="tel:1%20562%20867%205309" target="_self" style="margin: 0 0 4px 0">
<span class="qodef-icon-element icon_phone" style="font-size: 14px"></span> <span class="qodef-icon-text ">1 562 867 5309</span> </a>
<a class="qodef-icon-widget-holder" href="https://www.google.rs/maps/place/Charging+Bull/@40.7055242,-74.0133806,20z/data=!4m5!3m4!1s0x0:0xc7db393ae1eff521!8m2!3d40.7055537!4d-74.0134436" target="_blank">
<span class="qodef-icon-element icon_pin_alt" style="font-size: 14px"></span> <span class="qodef-icon-text ">Broadway &amp; Morris St, New York</span> </a>
</div>
<div class="qodef-column-content qodef-grid-col-3">
<div class="widget qodef-blog-list-widget"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title" style="margin-bottom: 26px">Our Recent Posts</h5></div><div class="qodef-blog-list-holder qodef-grid-list qodef-disable-bottom-space qodef-bl-minimal qodef-one-columns qodef-normal-space qodef-bl-pag-no-pagination" data-type=minimal data-number-of-posts=3 data-number-of-columns=one data-space-between-items=normal data-orderby=date data-order=ASC data-image-size=thumbnail data-title-tag=h6 data-excerpt-length=40 data-post-info-image=yes data-pagination-type=no-pagination data-widget-simple=no data-max-num-pages=9 data-next-page=2>
<div class="qodef-bl-wrapper qodef-outer-space">
<ul class="qodef-blog-list">
<li class="qodef-bl-item qodef-item-space clearfix">
<div class="qodef-bli-inner">
<div class="qodef-bli-content">
<h6 itemprop="name" class="entry-title qodef-post-title">
<a itemprop="url" href="https://setsail.qodeinteractive.com/visit-thailand-bali-and-china/" title="Visit Thailand, Bali And China">
Visit Thailand, Bali And China </a>
</h6> <div itemprop="dateCreated" class="qodef-post-info-date entry-date published updated">
<a itemprop="url" href="https://setsail.qodeinteractive.com/2016/09/">
September 7, 2016 </a>
<meta itemprop="interactionCount" content="UserComments: 0" />
</div> </div>
</div>
</li><li class="qodef-bl-item qodef-item-space clearfix">
<div class="qodef-bli-inner">
<div class="qodef-bli-content">
<h6 itemprop="name" class="entry-title qodef-post-title">
<a itemprop="url" href="https://setsail.qodeinteractive.com/the-sound-of-our-jungle/" title="The Sound Of Our Jungle">
The Sound Of Our Jungle </a>
</h6> <div itemprop="dateCreated" class="qodef-post-info-date entry-date published updated">
<a itemprop="url" href="https://setsail.qodeinteractive.com/2016/09/">
September 7, 2016 </a>
<meta itemprop="interactionCount" content="UserComments: 0" />
</div> </div>
</div>
</li><li class="qodef-bl-item qodef-item-space clearfix">
<div class="qodef-bli-inner">
<div class="qodef-bli-content">
<h6 itemprop="name" class="entry-title qodef-post-title">
<a itemprop="url" href="https://setsail.qodeinteractive.com/new-year-new-resolutions/" title="New Year, New Resolutions!">
New Year, New Resolutions! </a>
</h6> <div itemprop="dateCreated" class="qodef-post-info-date entry-date published updated">
<a itemprop="url" href="https://setsail.qodeinteractive.com/2016/09/">
September 7, 2016 </a>
<meta itemprop="interactionCount" content="UserComments: 0" />
</div> </div>
</div>
</li> </ul>
</div>
</div></div> </div>
<div class="qodef-column-content qodef-grid-col-3">
<div id="text-3" class="widget qodef-footer-column-3 widget_text"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">Subscribe to our Newsletter</h5></div> <div class="textwidget"><p><span style="color: #a9a9a9;">Etiam rhoncus. Maecenas temp us, tellus eget condimentum rho</span></p>
</div>
</div> <div class="widget qodef-contact-form-7-widget ">
<div role="form" class="wpcf7" id="wpcf7-f800-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/xmlrpc.php#wpcf7-f800-o1" method="post" class="wpcf7-form init cf7_custom_style_3" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="800" />
<input type="hidden" name="_wpcf7_version" value="5.4" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f800-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="qodef-custom-nlf-footer">
<div class="qodef-grid-row qodef-grid-normal-gutter">
<div><span class="qodef-newsletter-icon qodef-newsletter-name-icon icon_profile"></span><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Name" /></span></div>
<div><span class="qodef-newsletter-icon qodef-newsletter-email-icon icon_mail_alt"></span><span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" /></span></div></div><input type="submit" value="Subscribe" class="wpcf7-form-control wpcf7-submit" /></div><div class="wpcf7-response-output" aria-hidden="true"></div></form></div> </div>
</div>
<div class="qodef-column-content qodef-grid-col-3">
<div id="text-4" class="widget qodef-footer-column-4 widget_text"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">Our Instagram</h5></div> <div class="textwidget"><p><span style="color: #a9a9a9;">Aliquam lorem ante, dapibus inviver raqui feugiat a, tellus. Phasellus null</span></p>
</div>
</div><div id="qodef_instagram_widget-2" class="widget qodef-footer-column-4 widget_qodef_instagram_widget"> <ul class="qodef-instagram-feed clearfix qodef-col-5 qodef-instagram-gallery qodef-tiny-space">
<li>
<a href="https://www.instagram.com/p/BnYrW9ogfx3/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40550729_1902988519791897_8155378118322146980_n.jpg?_nc_cat=105&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=I364hKGpkYYAX8WDUSq&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=e20232c806d6c93d8d2b4efceac1a3d7&amp;oe=6173F392" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrVdKAsv7/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40481446_312794325966573_7238021377612713413_n.jpg?_nc_cat=102&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Njum0P8AlA4AX-KStm5&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=77cb9f3b3469398a93beaf4968af3329&amp;oe=6173CEBA" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrT24Ab1d/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/41087687_720569758279116_5219986637256948209_n.jpg?_nc_cat=111&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=rdlco4KXb_oAX8oiaMP&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=6c5f41b8e092d06d7a267424f3a62be8&amp;oe=61738DDF" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrSSEAvck/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/39948730_433290073863227_8438102480037573677_n.jpg?_nc_cat=100&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=9PNTl-wsSiQAX-AlcTi&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=5e20aa11b6adbfabdfeab20e4628ff37&amp;oe=6173CEFB" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrQuag-mT/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/41074418_340793066682119_1987037198157530486_n.jpg?_nc_cat=102&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=F5M89oCk-MAAX8KQna0&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=73e4c8f57e429364dd5eca2958ae6441&amp;oe=61742304" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrPRBAVOf/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40419870_296084594511455_8682518320629895026_n.jpg?_nc_cat=106&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=qSuH23rxeRAAX84XZTh&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=6a446a923f1ac1ecd9a5fc1b87e56524&amp;oe=61736F1E" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYrMy9A7s-/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/39933078_1778861865537301_9178762990586169390_n.jpg?_nc_cat=108&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=dUazQIKAr0EAX8lli1q&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=5b4c44b5b45b801232ff9a6205d097d2&amp;oe=6174ACED" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYq-HWgNuO/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40434429_708536679498397_8633299629858294087_n.jpg?_nc_cat=109&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=3csJ235Ff-AAX-ToKUj&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=302e22dbf22abc8656d793aad71dc788&amp;oe=617477C4" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYq8cbgSIN/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40808933_1806822246105865_2770821415596652047_n.jpg?_nc_cat=109&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=-dFDBIUfm18AX-JcGU0&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=4031b33a583d91be920ec25a262918f9&amp;oe=61742FAA" alt="" /> </a>
</li>
<li>
<a href="https://www.instagram.com/p/BnYq6sFAvI7/" target="_blank">
<img src="https://scontent-fml2-1.cdninstagram.com/v/t51.2885-15/40431710_258408881476133_5549904701930696493_n.jpg?_nc_cat=102&amp;ccb=1-5&amp;_nc_sid=8ae9d6&amp;_nc_ohc=aA9y2nrk6RoAX_d_DQb&amp;_nc_ht=scontent-fml2-1.cdninstagram.com&amp;edm=ANo9K5cEAAAA&amp;oh=28dca9e84403fb08db5fdd8f44aa1d62&amp;oe=61735F7F" alt="" /> </a>
</li>
</ul>
</div> </div>
</div>
</div>
</div><div class="qodef-footer-bottom-holder">
<div class="qodef-footer-bottom-inner qodef-full-width">
<div class="qodef-grid-row ">
<div class="qodef-grid-col-4">
</div>
<div class="qodef-grid-col-4">
<div id="text-7" class="widget qodef-footer-bottom-column-2 widget_text"> <div class="textwidget"><p style="font-size: 13px; text-align: center; color: #a9a9a9;">Powered by @ <a href="https://qodeinteractive.com/" target="_blank" rel="nofollow noopener">Qode Interactive 2018</a></p>
</div>
</div> </div>
<div class="qodef-grid-col-4">
</div>
</div>
</div>
</div> </footer>
</div> 
</div> 
<div class="rbt-toolbar" data-theme="SetSail" data-featured="" data-button-position="27%" data-button-horizontal="right" data-button-alt="no"></div><div class="qodef-login-register-holder">
<div class="qodef-login-register-content">
<ul>
<li><a href="#qodef-login-content">Login</a></li>
<li><a href="#qodef-register-content">Register</a></li>
</ul>
<div class="qodef-login-content-inner" id="qodef-login-content">
<div class="qodef-wp-login-holder"><div class="qodef-social-login-holder">
<div class="qodef-social-login-holder-inner">
<form method="post" class="qodef-login-form">
<h4 class="qodef-login-title">Sign In Here!</h4>
<p class="qodef-login-description">Log into your account in just a few simple steps.</p>
<fieldset>
<div>
<span class="qodef-login-icon icon_profile"></span>
<input type="text" name="user_login_name" id="user_login_name" placeholder="User Name" value="" required pattern=".{3,}" title="Three or more characters" />
</div>
<div>
<span class="qodef-login-icon icon_lock_alt"></span>
 <input type="password" name="user_login_password" id="user_login_password" placeholder="Password" value="" required />
</div>
<div class="qodef-lost-pass-remember-holder clearfix">
<span class="qodef-login-remember">
<input name="rememberme" value="forever" id="rememberme" type="checkbox" />
<label for="rememberme" class="qodef-checbox-label">Remember me</label>
</span>
</div>
<input type="hidden" name="redirect" id="redirect" value="">
<div class="qodef-login-button-holder">
<a href="https://setsail.qodeinteractive.com/my-account/lost-password/" class="qodef-login-action-btn" data-el="#qodef-reset-pass-content" data-title="Lost Password?">Lost Your password?</a>
<button type="submit" class="qodef-btn qodef-btn-medium qodef-btn-solid"> <span class="qodef-btn-text">Sign in</span> </button> <input type="hidden" id="qodef-login-security" name="qodef-login-security" value="c281c7bba9" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" /> </div>
</fieldset>
</form>
</div>
<div class="qodef-login-form-social-login">
<div class="qodef-login-social-title">
Sign in with Facebook or Google+ </div>
</div>
<div class="qodef-login-social-networks">
<form class="qodef-facebook-login-holder"><input type="hidden" id="qodef_nonce_facebook_login_707717587" name="qodef_nonce_facebook_login_707717587" value="42f4d4ef70" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" /><button type="submit" style="background-color: #3b5998;border-color: #3b5998" class="qodef-btn qodef-btn-small qodef-btn-solid qodef-btn-custom-hover-bg qodef-btn-custom-border-hover qodef-facebook-login" data-hover-bg-color="#4363A5" data-hover-border-color="#4363A5"> <span class="qodef-btn-text">FACEBOOK</span> </button></form><form class="qodef-google-login-holder"><input type="hidden" id="qodef_nonce_google_login_320745945" name="qodef_nonce_google_login_320745945" value="575cf8ee6d" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" /><button type="submit" style="background-color: #dd4b39;border-color: #dd4b39" class="qodef-btn qodef-btn-small qodef-btn-solid qodef-btn-custom-hover-bg qodef-btn-custom-border-hover qodef-google-login" data-hover-bg-color="#dd5543" data-hover-border-color="#dd5543"> <span class="qodef-btn-text">GOOGLE+</span> </button></form> </div>
<div class="qodef-membership-response-holder clearfix"></div><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/template" class="qodef-membership-response-template">
					<div class="qodef-membership-response <%= messageClass %> ">
						<div class="qodef-membership-response-message">
							<p><%= message %></p>
						</div>
					</div>
				</script></div></div>
</div>
<div class="qodef-register-content-inner" id="qodef-register-content">
<div class="qodef-wp-register-holder"><div class="qodef-social-register-holder">
<h4 class="qodef-register-title">Register Now!</h4>
<p class="qodef-register-description">Join the SetSail community today &amp; set up a free account.</p>
<form method="post" class="qodef-register-form">
<fieldset>
<div>
<span class="qodef-register-icon icon_profile"></span>
<input type="text" name="user_register_name" id="user_register_name" placeholder="User Name" value="" required pattern=".{3,}" title="Three or more characters" />
</div>
<div>
<span class="qodef-register-icon icon_mail_alt"></span>
<input type="email" name="user_register_email" id="user_register_email" placeholder="Email" value="" required />
</div>
<div>
<span class="qodef-register-icon icon_lock_alt"></span>
<input type="password" name="user_register_password" id="user_register_password" placeholder="Password" value="" required />
</div>
<div>
<span class="qodef-register-icon icon_lock_alt"></span>
<input type="password" name="user_register_confirm_password" id="user_register_confirm_password" placeholder="Repeat Password" value="" required />
</div>
<div class="qodef-register-button-holder">
<button type="submit" class="qodef-btn qodef-btn-medium qodef-btn-solid"> <span class="qodef-btn-text">Register</span> </button><input type="hidden" id="qodef-register-security" name="qodef-register-security" value="7b23fd42a5" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" /> </div>
</fieldset>
</form>
<div class="qodef-membership-response-holder clearfix"></div><script type="text/template" class="qodef-membership-response-template">
					<div class="qodef-membership-response <%= messageClass %> ">
						<div class="qodef-membership-response-message">
							<p><%= message %></p>
						</div>
					</div>
				</script></div></div>
</div>
</div>
</div>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M4XZBMN"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
 <script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill.min.js' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wp-polyfill-js-after'>
( 'fetch' in window ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-url.min.js"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js"></scr' + 'ipt>' );( 'objectFit' in document.documentElement.style ) || document.write( '<script src="https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-object-fit.min.js"></scr' + 'ipt>' );
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/hooks.min.js' id='wp-hooks-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/i18n.min.js' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/vendor/lodash.min.js' id='lodash-js'></script>
<script type='text/javascript' id='lodash-js-after'>
window.lodash = _.noConflict();
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/url.min.js' id='wp-url-js'></script>
<script type='text/javascript' id='wp-api-fetch-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/dist/api-fetch.min.js' id='wp-api-fetch-js'></script>
<script type='text/javascript' id='wp-api-fetch-js-after'>
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://setsail.qodeinteractive.com/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "3aac413181" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://setsail.qodeinteractive.com/wp-admin/admin-ajax.php?action=rest-nonce";
</script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=5.7' id='rabbit_js-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/underscore.min.js' id='underscore-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' id='setsail-select-modules-js-extra'>
/* <![CDATA[ */
var qodefGlobalVars = {"vars":{"qodefAddForAdminBar":0,"qodefElementAppearAmount":-100,"qodefAjaxUrl":"https:\/\/setsail.qodeinteractive.com\/wp-admin\/admin-ajax.php","sliderNavPrevArrow":"icon-arrows-left","sliderNavNextArrow":"icon-arrows-right","ppExpand":"Expand the image","ppNext":"Next","ppPrev":"Previous","ppClose":"Close","qodefStickyHeaderHeight":0,"qodefStickyHeaderTransparencyHeight":70,"qodefTopBarHeight":46,"qodefLogoAreaHeight":0,"qodefMenuAreaHeight":126,"qodefMobileHeaderHeight":70}};
var qodefPerPageVars = {"vars":{"qodefMobileHeaderHeight":70,"qodefStickyScrollAmount":730,"qodefHeaderTransparencyHeight":0,"qodefHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules.min.js' id='setsail-select-modules-js'></script>
<script type='text/javascript' id='setsail-membership-script-js-extra'>
/* <![CDATA[ */
var qodefSocialLoginVars = {"social":{"facebookAppId":"1897037670413390","googleClientId":""}};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-membership/assets/js/membership.min.js' id='setsail-membership-script-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/js/modules/plugins/nouislider.min.js' id='nouislider-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/js/modules/plugins/typeahead.bundle.min.js' id='typeahead-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/js/modules/plugins/bloodhound.min.js' id='bloodhound-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/ui/datepicker.min.js' id='jquery-ui-datepicker-js'></script>
<script type='text/javascript' id='jquery-ui-datepicker-js-after'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' id='setsail-tours-script-js-extra'>
/* <![CDATA[ */
var qodefToursSearchData = {"tours":["Beautiful Holland","Temple Tour","Caving","Ubud","Tarragona","Seminyak","Madrid","Denpasar","Barcelona","Active Winter","Kids Ski School","Snow Surfing","Skiing In Alps","Magic Of  Italy","Winter Action","New Year In Toronto","New Year On The Lake","China Avio 17 Days","Best New Year Ever","Berlin Avio 7 Days","The Best New Year","Australia Avio 14 Days","London Avio 5 days","Italy Bus 8 Days","Krakow Bus 5 Days","Jungle Adventure","Island Paradise","Bali Lanterns","Local Wines","Villages","Champagne","Harvest","Camping","Wine Tasting","Wine Festival","Marbella","Toronto","Romantic Paris","Holland Canals","Monuments","Hudson Sailing","Shopping Tour","Summer Fun","Italy Tour","Varadero","Valencia","Seville","Milan","Rome","Vatican City","Corfu","Tainan","Taipei","Kaohsiung","Sydney Opera"],"destinations":["Hiking","Country Side","Wine Tour","Holiday","Far Places","Exotic Places","France","Switzerland","Slovenia","San Marino","China","Indonesia","India","Italy","Russia","Cuba","Egypt","New York","Japan","Bali","Australia","Spain","Netherlands","Greece","Taiwan"]};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-tours/assets/js/tours.min.js' id='setsail-tours-script-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_3f86dcd62f9ffc319b72a234fcbc3060","fragment_name":"wc_fragments_3f86dcd62f9ffc319b72a234fcbc3060","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='qi-addons-for-elementor-script-js-extra'>
/* <![CDATA[ */
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js' id='qi-addons-for-elementor-script-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/jquery/ui/accordion.min.js' id='jquery-ui-accordion-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.appear.js' id='appear-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/modernizr.min.js' id='modernizr-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/hoverIntent.min.js' id='hoverIntent-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.plugin.js' id='jquery-plugin-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/owl.carousel.min.js' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.waypoints.min.js' id='waypoints-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/fluidvids.min.js' id='fluidvids-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/ScrollToPlugin.min.js' id='ScrollToPlugin-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/parallax.min.js' id='parallax-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.waitforimages.js' id='waitforimages-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.prettyPhoto.js' id='prettyphoto-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.easing.1.3.js' id='jquery-easing-1.3-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js' id='isotope-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/masonry/assets/js/plugins/packery-mode.pkgd.min.js' id='packery-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/themes/setsail/assets/js/modules/plugins/jquery.mousewheel.min.js' id='jquery-mousewheel-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js' id='select2-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/shortcodes/countdown/assets/js/plugins/jquery.countdown.min.js' id='countdown-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/shortcodes/counter/assets/js/plugins/counter.js' id='counter-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/shortcodes/counter/assets/js/plugins/absoluteCounter.min.js' id='absoluteCounter-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/shortcodes/typeout-text/assets/js/plugins/typed.js' id='typed-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/shortcodes/full-screen-sections/assets/js/plugins/jquery.fullPage.min.js' id='fullPage-js'></script>
<script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-content/plugins/setsail-core/shortcodes/vertical-split-slider/assets/js/plugins/jquery.multiscroll.min.js' id='multiscroll-js'></script>
<script type='text/javascript' src='//maps.googleapis.com/maps/api/js?key=AIzaSyDm0zEJ3h0OeMp_qsvHIzcx_5w5HJVH1L4&#038;ver=5.7' id='setsail-select-google-map-api-js'></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&#038;ver=5.7" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no") {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script><script type='text/javascript' src='https://setsail.qodeinteractive.com/wp-includes/js/wp-embed.min.js' id='wp-embed-js'></script>
</body>
</html>
